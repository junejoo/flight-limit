package com.finalexam.capstone1.alarms;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.finalexam.capstone1.MainActivity;
import com.finalexam.capstone1.MypageActivity;
import com.finalexam.capstone1.R;

import java.util.ArrayList;
import java.util.Date;

public class MypageAlarmsActivity extends AppCompatActivity {

    ImageButton btn_home, btn_profile;
    ListView lv_alarm;
    ArrayList<Alarm> list;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.mypage_alarm);

        lv_alarm = (ListView) findViewById(R.id.lv_alarm);
        test_listview();
        AlarmListAdapter adapter = new AlarmListAdapter(list);
        lv_alarm.setAdapter(adapter);


        btn_home = (ImageButton) findViewById(R.id.btn_ma_home);
        btn_home.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(view.getContext(), MainActivity.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                intent.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
                startActivity(intent);
            }
        });
        btn_profile = (ImageButton) findViewById(R.id.btn_ma_profile);
        btn_profile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(view.getContext(), MypageActivity.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                intent.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
                startActivity(intent);
            }
        });


    }

    void test_listview() {
        list = new ArrayList<>();

        list.add(new Alarm("ICN", "CJU", "Any airline", 1, 0, "20.06.30", "10,000"));
        list.add(new Alarm("ICN", "NRT", "Any airline", 1, 0, "20.06.30", "50,000"));
        list.add(new Alarm("ICN", "TPE", "Any airline", 1, 0, "20.06.30", "30,000"));

        list.add(new Alarm("GMP", "CJU", "Any airline", 1, 0, "20.06.30", "8,000"));
        list.add(new Alarm("ICN", "HND", "Any airline", 1, 0, "20.06.30", "50,000"));

    }


    class AlarmListAdapter extends BaseAdapter {

        ArrayList<Alarm> list;

        AlarmListAdapter(ArrayList<Alarm> list) {
            this.list = list;
        }


        @Override
        public int getCount() {
            return list.size();
        }

        @Override
        public Object getItem(int i) {
            return list.get(i);
        }

        @Override
        public long getItemId(int i) {
            return i;
        }

        @Override
        public View getView(final int i, View view, ViewGroup viewGroup) {
            final Context context = viewGroup.getContext();

            if (view == null) {
                LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
                view = inflater.inflate(R.layout.mypage_alarm_listitem , viewGroup, false);
            }

            TextView tv_airport = (TextView) view.findViewById(R.id.tv_alarm_airport);
            TextView tv_date = (TextView) view.findViewById(R.id.tv_alarm_date);
            TextView tv_price = (TextView) view.findViewById(R.id.tv_alarm_price);
            TextView tv_detail = (TextView) view.findViewById(R.id.tv_alarm_detail);

            Alarm lv_item = list.get(i);
            tv_airport.setText(lv_item.dept + "    to    " + lv_item.arrv);
            tv_date.setText(lv_item.date);
            tv_price.setText(lv_item.price);
            tv_detail.setText(lv_item.adlt + " Adult, " + lv_item.airl);

            // list view click evnet
            view.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Toast.makeText(context, "clicked", Toast.LENGTH_SHORT).show();
                }
            });

            return view;
        }
    }
}
