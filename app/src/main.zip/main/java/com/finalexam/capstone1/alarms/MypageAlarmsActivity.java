package com.finalexam.capstone1.alarms;

import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.finalexam.capstone1.R;

import java.util.ArrayList;
import java.util.Date;

public class MypageAlarmsActivity extends AppCompatActivity {
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.mypage_alarm);


    }





    class BaseAdapter_alarms extends BaseAdapter {

        private ArrayList<Alarm> data = new ArrayList<Alarm>();

        BaseAdapter_alarms() {

        }

        public void addData(String dept, String arrv, String airl,
                            int adlt, int chld, Date date, Boolean stop) {
            data.add(new Alarm(dept, arrv, airl, adlt, chld, date, stop));
        }

        @Override
        public int getCount() {
            return 0;
        }

        @Override
        public Object getItem(int i) {
            return null;
        }

        @Override
        public long getItemId(int i) {
            return 0;
        }

        @Override
        public View getView(int i, View view, ViewGroup viewGroup) {
            return null;
        }
    }
}
