package com.finalexam.capstone1.flight;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.annotation.Nullable;

import com.finalexam.capstone1.R;

public class SetAlarmDetailActivity extends Activity {

    private Button btn_save;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.f_alarm1);

        btn_save = (Button)findViewById(R.id.btn_fsavealarm2);
        btn_save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(view.getContext(), PriceDistributionActivity.class);
                startActivity(intent);
            }
        });

    }
}
