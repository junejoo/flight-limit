package com.finalexam.capstone1.flight;

import android.annotation.SuppressLint;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.finalexam.capstone1.MainActivity;
import com.finalexam.capstone1.R;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.Locale;

public class AirportDialog extends Dialog {

    AirportDialog m_aDialog;
    static boolean dep_arr = true;
    Button btn;
    private AirportListViewAdapter adapter; // 리스트뷰에 연결할 어답터
    private EditText et_airport;
    private ListView lv_airport;

    private List<Airport> list;
    private ArrayList<Airport> arraylist;

    public AirportDialog(Context context, boolean dep_arr) {
        super(context, android.R.style.Theme_Translucent_NoTitleBar);
//        AirportDialog.dep_arr = dep_arr;
//        if (dep_arr)    btn = (Button) findViewById(R.id.btn_fsearch_dep);
//        else            btn = (Button) findViewById(R.id.btn_fsearch_arr);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        WindowManager.LayoutParams lpWindow = new WindowManager.LayoutParams();
        lpWindow.flags = WindowManager.LayoutParams.FLAG_DIM_BEHIND;
        lpWindow.dimAmount = 0.5f;
        getWindow().setAttributes(lpWindow);

        setContentView(R.layout.dialog_airport);
        m_aDialog = this;

        init();

        et_airport.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void afterTextChanged(Editable editable) {
                String text = et_airport.getText().toString()
                        .toUpperCase(Locale.getDefault());
                adapter.filter(text);
            }
        });
    }

    void init() {
        et_airport = (EditText)findViewById(R.id.et_airport);
        lv_airport = (ListView)findViewById(R.id.lv_airport);

//        AirportList airportList = new AirportList(getContext());
        list = new ArrayList<Airport>();
        settingList();  // 검색에 사용할 데이터 저장 (공항 목록)

//        arraylist = new ArrayList<Airport>();
//        arraylist.addAll(list);

        adapter = new AirportListViewAdapter(getContext(), list);
        lv_airport.setAdapter(adapter);

        ///////
//        lv_airport.setOnItemClickListener(new AdapterView.OnItemClickListener() {
//            @Override
//            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
////                Button btn;
////                if (dep_arr) btn = (Button)findViewById(R.id.btn_fsearch_dep);
////                else         btn = (Button)findViewById(R.id.btn_fsearch_arr);
//
////                btn = (Button)findViewById(R.id.btn_fsearch_dep);
////                btn.setBackgroundColor(Color.green(343434));
//                btn.setText("GOOD");
//
//                m_aDialog.dismiss();
//            }
//        });

    }

    public void onClickBtn (View _oView)
    {
        this.dismiss(); // Dialog exit
    }

    private void settingList() {
        // 대한민국
        list.add(new Airport("ICN", "서울 인천국제공항"));
        list.add(new Airport("GMP", "서울 김포국제공항"));
        list.add(new Airport("PUS", "부산 김해공항"));
        list.add(new Airport("CJU", "제주공항"));

        // 동북아시아
        list.add(new Airport("NRT", "일본 도쿄 나리타 공항"));
        list.add(new Airport("HND", "일본 도쿄 하네다 공항"));
        list.add(new Airport("KIX", "일본 오사카 칸사이 공항"));
        list.add(new Airport("PEK", "중국 베이징 셔우뚜 공항"));
        list.add(new Airport("PVG", "중국 상하이 푸동 공항"));
        list.add(new Airport("HKG", "홍콩 첵랍콕 공항"));
        list.add(new Airport("TPE", "대만 타오위안 공항"));
        list.add(new Airport("ULN", "몽골 울란바토르 칭기즈칸 공항"));

        // 동남아시아
        list.add(new Airport("CGK", "인도네시아 자카르타 수카르노 하타 공항"));
        list.add(new Airport("PNH", "캄보디아 프놈펜 공항"));
        list.add(new Airport("HAN", "베트남 하노이 공항"));
        list.add(new Airport("VTE", "라오스 비엔티안 왓따이 공항"));
        list.add(new Airport("DEL", "인도 델리 인디라 간디 공항"));
        list.add(new Airport("CMB", "스리랑카 콜롬보 반다라나이케 공항"));
        list.add(new Airport("KUL", "말레이시아 쿠알라룸프르 공항"));
        list.add(new Airport("BKK", "태국 방콕 공항"));
        list.add(new Airport("MNL", "필리핀 마닐라 니노이 아키노 공항"));

        // 서남아시아
        list.add(new Airport("AUH", "UAE 아부다비 공항"));
        list.add(new Airport("DXB", "UAE 두바이 공항"));
        list.add(new Airport("DOH", "카타르 도하 공항"));
        list.add(new Airport("IST", "타키 이스탄불 아타튀르크 공항"));

        // 유럽
        list.add(new Airport("LHR", "영국 런던 히드로 공항"));
        list.add(new Airport("LGW", "영국 런던 가크윅 공항"));
        list.add(new Airport("CDG", "프랑스 파리 샤를 드 골 공항"));
        list.add(new Airport("ORY", "프랑스 파리 오를리 공항"));
        list.add(new Airport("FRA", "독일 프랑크푸르트 공항"));
        list.add(new Airport("MAD", "스페인 마드리드 공항"));
        list.add(new Airport("FCO", "이탈리아 로마 레오나르도 다 빈치 공항"));
        list.add(new Airport("DME", "러시아 모스크바 도모데오보 공항"));
        list.add(new Airport("SVO", "러시아 모스크바 셰레메쪠보 공항"));
        list.add(new Airport("TAS", "우즈베키스탄 타슈켄트 공항"));
        list.add(new Airport("HEL", "핀란드 헬싱키 공항"));
        list.add(new Airport("AMS", "네덜란드 암스테르담 스키폴 공항"));

        // 아프리카
        list.add(new Airport("CMN", "모로코 카사블랑카 모하메드 5세 공항"));
        list.add(new Airport("RBA", "모로코 라밧 살레 공항"));
        list.add(new Airport("TUN", "튀니지 튀니스 공항"));
        list.add(new Airport("ADD", "에티오피아 아디스아바바 볼레 공항"));
        list.add(new Airport("CAI", "이집트 카이로 공항"));
        list.add(new Airport("NBO", "케냐 나이로비 공항"));
        list.add(new Airport("TIP", "리비아 트리폴리 공항"));
        list.add(new Airport("KGL", "르완다 키갈리 공항"));
        list.add(new Airport("DAR", "탄자니아 다르에스살람 공항"));
        list.add(new Airport("JNB", "남아프리카공화국 조하네스버스 공항"));
        list.add(new Airport("NSI", "카메룬 아운데 공항"));
        list.add(new Airport("DKR", "세네갈 다카 공항"));

        // 북미
        list.add(new Airport("SEA", "미국 시애틀 공항"));
        list.add(new Airport("SFO", "미국 샌프란시스코 공항"));
        list.add(new Airport("LAX", "미국 로스앤젤레스 공항"));
        list.add(new Airport("LAS", "미국 라스베이거스 공항"));
        list.add(new Airport("ORD", "미국 시카고 오헤어 공항"));
        list.add(new Airport("MDW", "미국 시카고 미드웨이 공항"));
        list.add(new Airport("JFK", "미국 뉴욕 존F 케네디 공항"));
        list.add(new Airport("LGA", "미국 뉴욕 라구아디아 공항"));
        list.add(new Airport("DTT", "미국 디트로이트 공항"));
        list.add(new Airport("ATL", "미국 애틀란타 공항"));
        list.add(new Airport("MIA", "미국 마이애미 공항"));
        list.add(new Airport("YVR", "캐나다 벤쿠버 공항"));
        list.add(new Airport("YYZ", "캐나다 토론토 피어슨 공항"));
        list.add(new Airport("YUL", "캐나다 몬트리올 공항"));
    }
}

