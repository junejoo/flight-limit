package com.finalexam.capstone1.alarms;

import java.util.Date;

public class Alarm {

    private String dept, arrv, airl;   // 출발지, 도착지, 항공사
    private int adlt, chld; // 성인, 아동 인원
    private Date date;      // 출발날짜
    private Boolean stop;   // 경유여부 (경유True, 직항False)

    public Alarm(String dept, String arrv, String airl, int adlt, int chld, Date date, Boolean stop) {
        this.dept = dept;
        this.arrv = arrv;
        this.airl = airl;
        this.adlt = adlt;
        this.chld = chld;
        this.date = date;
        this.stop = stop;
    }

    // getter & setter ----------
    public String getDept() {
        return dept;
    }

    public void setDept(String dept) {
        this.dept = dept;
    }

    public String getArrv() {
        return arrv;
    }

    public void setArrv(String arrv) {
        this.arrv = arrv;
    }

    public String getAirl() {
        return airl;
    }

    public void setAirl(String airl) {
        this.airl = airl;
    }

    public int getAdlt() {
        return adlt;
    }

    public void setAdlt(int adlt) {
        this.adlt = adlt;
    }

    public int getChld() {
        return chld;
    }

    public void setChld(int chld) {
        this.chld = chld;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public Boolean getStop() {
        return stop;
    }

    public void setStop(Boolean stop) {
        this.stop = stop;
    }
}
