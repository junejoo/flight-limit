package com.finalexam.capstone1.flight;

import android.content.Context;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;

public class AirportList implements List<Airport> {

    private Context context;

    AirportList(Context context) {
        this.context = context;
    }

    @Override
    public int size() {
        return 0;
    }

    @Override
    public boolean isEmpty() {
        return false;
    }

    @Override
    public boolean contains(@Nullable Object o) {
        return false;
    }

    @NonNull
    @Override
    public Iterator<Airport> iterator() {
        return null;
    }

    @NonNull
    @Override
    public Object[] toArray() {
        return new Object[0];
    }

    @NonNull
    @Override
    public <T> T[] toArray(@NonNull T[] ts) {
        return null;
    }

    @Override
    public boolean add(Airport airport) {
        return false;
    }

    @Override
    public boolean remove(@Nullable Object o) {
        return false;
    }

    @Override
    public boolean containsAll(@NonNull Collection<?> collection) {
        return false;
    }

    @Override
    public boolean addAll(@NonNull Collection<? extends Airport> collection) {
        return false;
    }

    @Override
    public boolean addAll(int i, @NonNull Collection<? extends Airport> collection) {
        return false;
    }

    @Override
    public boolean removeAll(@NonNull Collection<?> collection) {
        return false;
    }

    @Override
    public boolean retainAll(@NonNull Collection<?> collection) {
        return false;
    }

    @Override
    public void clear() {

    }

    @Override
    public Airport get(int i) {
        return null;
    }

    @Override
    public Airport set(int i, Airport airport) {
        return null;
    }

    @Override
    public void add(int i, Airport airport) {

    }

    @Override
    public Airport remove(int i) {
        return null;
    }

    @Override
    public int indexOf(@Nullable Object o) {
        return 0;
    }

    @Override
    public int lastIndexOf(@Nullable Object o) {
        return 0;
    }

    @NonNull
    @Override
    public ListIterator<Airport> listIterator() {
        return null;
    }

    @NonNull
    @Override
    public ListIterator<Airport> listIterator(int i) {
        return null;
    }

    @NonNull
    @Override
    public List<Airport> subList(int i, int i1) {
        return null;
    }
}

class Airport {
    String name_en, name_kr;

    Airport(String name_en, String name_kr) {
        this.name_en = name_en;
        this.name_kr = name_kr;
    }
}